import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Trophy, Medal, Star, Crown, ArrowLeft, RefreshCw } from 'lucide-react'

const HighScores = ({ onBack }) => {
  const [highScores, setHighScores] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [lastUpdated, setLastUpdated] = useState(null)

  const loadHighScores = async () => {
    setLoading(true)
    setError(null)
    
    try {
      // Intentar primero con el servidor desplegado
      let response
      try {
        response = await fetch('https://9yhyi3cp76mo.manus.space/api/game/highscores')
      } catch (deployError) {
        // Fallback a localhost
        response = await fetch('http://localhost:5000/api/game/highscores')
      }
      
      const data = await response.json()
      if (data.success) {
        setHighScores(data.data)
        setLastUpdated(new Date())
      } else {
        setError(data.error || 'Error al cargar los high scores')
      }
    } catch (error) {
      console.error('Error loading high scores:', error)
      setError('Error de conexión al cargar los high scores')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    loadHighScores()
  }, [])

  const getRankIcon = (rank) => {
    switch (rank) {
      case 1:
        return <Crown className="w-6 h-6 text-yellow-500" />
      case 2:
        return <Trophy className="w-6 h-6 text-gray-400" />
      case 3:
        return <Medal className="w-6 h-6 text-orange-500" />
      default:
        return <Star className="w-6 h-6 text-blue-500" />
    }
  }

  const getRankColor = (rank) => {
    switch (rank) {
      case 1:
        return 'bg-gradient-to-r from-yellow-400 to-yellow-600 text-white'
      case 2:
        return 'bg-gradient-to-r from-gray-300 to-gray-500 text-white'
      case 3:
        return 'bg-gradient-to-r from-orange-400 to-orange-600 text-white'
      default:
        return 'bg-gradient-to-r from-blue-400 to-blue-600 text-white'
    }
  }

  const getModuleName = (moduleId) => {
    const moduleNames = {
      1: 'Puerto del Descubrimiento',
      2: 'Valle de Ingresos y Gastos',
      3: 'Cueva del Ahorro',
      4: 'Mercado del Emprendedor',
      5: 'Bosque de la Honestidad',
      6: 'Fuente del Crecimiento',
      7: 'Montañas de los Desafíos',
      8: 'Cima del Éxito'
    }
    return moduleNames[moduleId] || `Módulo ${moduleId}`
  }

  const formatDate = (dateString) => {
    const date = new Date(dateString)
    return date.toLocaleDateString('es-ES', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    })
  }

  if (loading) {
    return (
      <div className="adventure-bg min-h-screen">
        <header className="bg-white/90 backdrop-blur-sm shadow-lg">
          <div className="container mx-auto px-4 py-4">
            <div className="flex justify-between items-center">
              <div className="flex items-center space-x-4">
                <Button variant="ghost" onClick={onBack}>
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Volver al Mapa
                </Button>
                <h1 className="text-3xl font-bold text-blue-800">🏆 High Scores</h1>
              </div>
            </div>
          </div>
        </header>
        
        <div className="container mx-auto px-4 py-8">
          <div className="flex justify-center items-center h-64">
            <div className="text-center">
              <RefreshCw className="w-8 h-8 animate-spin mx-auto mb-4 text-blue-600" />
              <p className="text-lg text-gray-600">Cargando high scores...</p>
            </div>
          </div>
        </div>
      </div>
    )
  }

  if (error) {
    return (
      <div className="adventure-bg min-h-screen">
        <header className="bg-white/90 backdrop-blur-sm shadow-lg">
          <div className="container mx-auto px-4 py-4">
            <div className="flex justify-between items-center">
              <div className="flex items-center space-x-4">
                <Button variant="ghost" onClick={onBack}>
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Volver al Mapa
                </Button>
                <h1 className="text-3xl font-bold text-blue-800">🏆 High Scores</h1>
              </div>
            </div>
          </div>
        </header>
        
        <div className="container mx-auto px-4 py-8">
          <Card className="max-w-md mx-auto">
            <CardContent className="text-center py-8">
              <p className="text-red-600 mb-4">{error}</p>
              <Button onClick={loadHighScores}>
                <RefreshCw className="w-4 h-4 mr-2" />
                Reintentar
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    )
  }

  return (
    <div className="adventure-bg min-h-screen">
      <header className="bg-white/90 backdrop-blur-sm shadow-lg">
        <div className="container mx-auto px-4 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-4">
              <Button variant="ghost" onClick={onBack}>
                <ArrowLeft className="w-4 h-4 mr-2" />
                Volver al Mapa
              </Button>
              <h1 className="text-3xl font-bold text-blue-800">🏆 High Scores</h1>
              <Badge variant="secondary">
                Top {highScores.length} Estudiantes
              </Badge>
            </div>
            <div className="flex items-center space-x-4">
              <Button variant="outline" onClick={loadHighScores}>
                <RefreshCw className="w-4 h-4 mr-2" />
                Actualizar
              </Button>
              {lastUpdated && (
                <Badge variant="outline" className="text-xs">
                  Actualizado: {lastUpdated.toLocaleTimeString('es-ES')}
                </Badge>
              )}
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <Card className="mb-8">
            <CardHeader>
              <CardTitle className="text-center text-2xl">🌟 Ranking de Aventureros Financieros</CardTitle>
              <CardDescription className="text-center">
                Los mejores puntajes de todos los módulos completados
              </CardDescription>
            </CardHeader>
          </Card>

          {highScores.length === 0 ? (
            <Card>
              <CardContent className="text-center py-12">
                <Trophy className="w-16 h-16 mx-auto mb-4 text-gray-400" />
                <h3 className="text-xl font-semibold mb-2">¡Sé el primero!</h3>
                <p className="text-gray-600">
                  Aún no hay high scores registrados. ¡Completa un módulo para aparecer en el ranking!
                </p>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-4">
              {highScores.map((score, index) => (
                <Card 
                  key={`${score.student_nip}-${score.module_id}-${index}`}
                  className={`overflow-hidden transition-all duration-300 hover:shadow-lg ${
                    score.rank <= 3 ? 'ring-2 ring-yellow-400' : ''
                  }`}
                >
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-4">
                        <div className={`flex items-center justify-center w-12 h-12 rounded-full ${getRankColor(score.rank)}`}>
                          {getRankIcon(score.rank)}
                        </div>
                        <div>
                          <h3 className="text-lg font-bold">
                            #{score.rank} - Estudiante {score.student_nip}
                          </h3>
                          <p className="text-sm text-gray-600">
                            {getModuleName(score.module_id)}
                          </p>
                          <p className="text-xs text-gray-500">
                            Logrado el {formatDate(score.achieved_at)}
                          </p>
                        </div>
                      </div>
                      
                      <div className="text-right">
                        <div className="text-3xl font-bold text-blue-600">
                          {score.score}
                        </div>
                        <div className="text-sm text-gray-600">puntos</div>
                        <Badge 
                          variant={score.score >= 90 ? "default" : score.score >= 70 ? "secondary" : "outline"}
                          className="mt-1"
                        >
                          {score.score >= 90 ? "Excelente" : score.score >= 70 ? "Bueno" : "Regular"}
                        </Badge>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}

          <Card className="mt-8">
            <CardContent className="text-center py-6">
              <h3 className="text-lg font-semibold mb-2">💡 ¿Cómo mejorar tu puntaje?</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm text-gray-600">
                <div>
                  <Star className="w-5 h-5 mx-auto mb-2 text-yellow-500" />
                  <p>Responde correctamente todas las preguntas</p>
                </div>
                <div>
                  <Trophy className="w-5 h-5 mx-auto mb-2 text-blue-500" />
                  <p>Completa todas las actividades del módulo</p>
                </div>
                <div>
                  <Medal className="w-5 h-5 mx-auto mb-2 text-green-500" />
                  <p>Toma decisiones financieras inteligentes</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

export default HighScores
