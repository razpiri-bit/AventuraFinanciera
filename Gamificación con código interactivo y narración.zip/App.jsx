import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Progress } from '@/components/ui/progress.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Coins, Star, Trophy, MapPin, Play, Volume2, LogOut } from 'lucide-react'
import GameModule from './components/GameModule.jsx'
import LoginForm from './components/LoginForm.jsx'
import RegistrationForm from './components/RegistrationForm.jsx'
import WelcomeScreen from './components/WelcomeScreen.jsx'
import './App.css'

// Importar imágenes de personajes
import capitanAhorroImg from './assets/images/characters/Capitan_Ahorro.png'
import emprendedoraLuciaImg from './assets/images/characters/Emprendedora_Lucia.png'
import eticaElenaImg from './assets/images/characters/Etica_Elena.png'
import monstruoGastoImg from './assets/images/characters/Monstruo_del_Gasto.png'
import huchaMagicaImg from './assets/images/characters/Hucha_Magica.png'

// Importar imágenes de entornos
import puertoDescubrimientoImg from './assets/images/environments/Puerto_del_Descubrimiento.png'
import valleIngresosGastosImg from './assets/images/environments/Valle_Ingresos_Gastos.png'
import cuevaAhorroImg from './assets/images/environments/Cueva_del_Ahorro.png'
import mercadoEmprendedorImg from './assets/images/environments/Mercado_del_Emprendedor.png'
import bosqueHonestidadImg from './assets/images/environments/Bosque_de_la_Honestidad.png'
import fuenteCrecimientoImg from './assets/images/environments/Fuente_del_Crecimiento.png'
import montanasDesafiosImg from './assets/images/environments/Montanas_de_los_Desafios.png'
import cimaExitoImg from './assets/images/environments/Cima_del_Exito.png'

// Importar audios
import capitanAhorroAudio from './assets/audio/Capitan_Ahorro_intro.wav'
import emprendedoraLuciaAudio from './assets/audio/Emprendedora_Lucia_intro.wav'
import eticaElenaAudio from './assets/audio/Etica_Elena_intro.wav'
import monstruoGastoAudio from './assets/audio/Monstruo_del_Gasto_intro.wav'
import huchaMagicaAudio from './assets/audio/Hucha_Magica_intro.wav'
import welcomeVideo from './assets/videos/Video_De_Isla_Del_Tesoro_Financiero.mp4'

function App() {
  const [currentView, setCurrentView] = useState("welcome") // 'welcome', 'login', 'register', 'map', 'module'
  const [currentModule, setCurrentModule] = useState(null)
  const [currentUser, setCurrentUser] = useState(null)
  const [userProgress, setUserProgress] = useState({
    coins: 100,
    level: 1,
    completed_modules: [],
    badges: []
  })
  const [showCharacterModal, setShowCharacterModal] = useState(false)
  const [selectedCharacter, setSelectedCharacter] = useState(null)
  const [sessionId, setSessionId] = useState(null)

  const characters = [
    {
      name: 'Capitán Ahorro',
      description: 'Tu sabio guía en la Isla del Tesoro Financiero',
      image: capitanAhorroImg,
      audio: capitanAhorroAudio,
      role: 'Mentor'
    },
    {
      name: 'Emprendedora Lucía',
      description: 'La joven entusiasta del emprendimiento',
      image: emprendedoraLuciaImg,
      audio: emprendedoraLuciaAudio,
      role: 'Emprendedora'
    },
    {
      name: 'Ética Elena',
      description: 'La guardiana de la honestidad y la justicia',
      image: eticaElenaImg,
      audio: eticaElenaAudio,
      role: 'Ética'
    },
    {
      name: 'Monstruo del Gasto',
      description: 'El travieso que representa los gastos impulsivos',
      image: monstruoGastoImg,
      audio: monstruoGastoAudio,
      role: 'Desafío'
    },
    {
      name: 'Hucha Mágica',
      description: 'El cofre parlante que guarda tus ahorros',
      image: huchaMagicaImg,
      audio: huchaMagicaAudio,
      role: 'Tesoro'
    }
  ]

  const modules = [
    {
      id: 1,
      title: 'Puerto del Descubrimiento',
      subtitle: 'El Mundo de las Finanzas',
      description: 'Descubre qué son las finanzas y cómo influyen en tu vida',
      image: puertoDescubrimientoImg,
      difficulty: 'Fácil',
      coins: 20,
      character: 'Capitán Ahorro'
    },
    {
      id: 2,
      title: 'Valle de los Ingresos y Gastos',
      subtitle: '¿De Dónde Viene y a Dónde Va?',
      description: 'Aprende sobre ingresos, gastos y cómo gestionar tu dinero',
      image: valleIngresosGastosImg,
      difficulty: 'Fácil',
      coins: 25,
      character: 'Capitán Ahorro'
    },
    {
      id: 3,
      title: 'Cueva del Ahorro',
      subtitle: 'La Magia del Ahorro',
      description: 'Descubre cómo el ahorro te ayuda a lograr tus metas',
      image: cuevaAhorroImg,
      difficulty: 'Medio',
      coins: 30,
      character: 'Hucha Mágica'
    },
    {
      id: 4,
      title: 'Mercado del Emprendedor',
      subtitle: 'Tu Propio Negocio',
      description: 'Crea tu primer negocio y aprende sobre emprendimiento',
      image: mercadoEmprendedorImg,
      difficulty: 'Medio',
      coins: 35,
      character: 'Emprendedora Lucía'
    },
    {
      id: 5,
      title: 'Bosque de la Honestidad',
      subtitle: 'La Ética en los Negocios',
      description: 'Aprende que la honestidad es clave para el éxito',
      image: bosqueHonestidadImg,
      difficulty: 'Medio',
      coins: 40,
      character: 'Ética Elena'
    },
    {
      id: 6,
      title: 'Fuente del Crecimiento',
      subtitle: 'El Poder de la Inversión',
      description: 'Descubre cómo las inversiones hacen crecer tu dinero',
      image: fuenteCrecimientoImg,
      difficulty: 'Difícil',
      coins: 45,
      character: 'Hucha Mágica'
    },
    {
      id: 7,
      title: 'Montañas de los Desafíos',
      subtitle: 'Los Obstáculos y Cómo Superarlos',
      description: 'Aprende a superar los desafíos financieros',
      image: montanasDesafiosImg,
      difficulty: 'Difícil',
      coins: 50,
      character: 'Monstruo del Gasto'
    },
    {
      id: 8,
      title: 'Cima del Éxito',
      subtitle: 'Hacia el Éxito Financiero',
      description: 'Celebra tu camino hacia el éxito financiero',
      image: cimaExitoImg,
      difficulty: 'Maestro',
      coins: 100,
      character: 'Capitán Ahorro'
    }
  ]

  const handleLogin = (userData) => {
    setCurrentUser(userData.student)
    setUserProgress(userData.progress)
    setSessionId(userData.session_id)
    setCurrentView('map')
  }

  const handleRegistrationComplete = (nip) => {
    // Después del registro, hacer login automático
    fetch(`https://qjh9iec7wzzk.manus.space/api/auth/login/${nip}`)
      .then(response => response.json())
      .then(data => {
        if (data.success) {
          handleLogin(data.user)
        }
      })
      .catch(error => {
        console.error('Error en login automático:', error)
        setCurrentView('login')
      })
  }

  const handleLogout = async () => {
    if (sessionId) {
      try {
        await fetch(`https://qjh9iec7wzzk.manus.space/api/auth/logout/${sessionId}`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            modules_completed: userProgress.completed_modules,
            activities_completed: userProgress.completed_modules.length,
            coins_earned: userProgress.coins - 100 // Monedas ganadas desde el inicio
          })
        })
      } catch (error) {
        console.error('Error al cerrar sesión:', error)
      }
    }
    
    setCurrentUser(null)
    setUserProgress({ coins: 100, level: 1, completed_modules: [], badges: [] })
    setSessionId(null)
    setCurrentView('login')
  }

  const loadUserProgress = async () => {
    if (!currentUser) return
    
    try {
      const userId = `student_${currentUser.nip}`
      const response = await fetch(`http://localhost:5000/api/game/progress/${userId}`)
      const data = await response.json()
      if (data.success) {
        setUserProgress(data.data)
      }
    } catch (error) {
      console.error('Error loading user progress:', error)
    }
  }

  const completeModule = async (moduleId, score) => {
    if (!currentUser) return
    
    try {
      const userId = `student_${currentUser.nip}`
      const response = await fetch(`http://localhost:5000/api/game/complete-module/${userId}/${moduleId}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ score })
      })
      const data = await response.json()
      if (data.success) {
        setUserProgress(data.data)
        
        // Mostrar mensaje de éxito
        alert(`¡Felicidades ${currentUser.nombre}! Has completado el módulo y ganado ${data.coins_earned} monedas.`)
        
        // Volver al mapa
        setCurrentView('map')
        setCurrentModule(null)
      }
    } catch (error) {
      console.error('Error completing module:', error)
    }
  }

  const playCharacterAudio = (character) => {
    const audio = new Audio(character.audio)
    audio.play()
  }

  const openCharacterModal = (character) => {
    setSelectedCharacter(character)
    setShowCharacterModal(true)
  }

  const startModule = (moduleId) => {
    const module = modules.find(m => m.id === moduleId)
    setCurrentModule(module)
    setCurrentView('module')
  }

  const backToMap = () => {
    setCurrentView('map')
    setCurrentModule(null)
  }

  const getDifficultyColor = (difficulty) => {
    switch (difficulty) {
      case 'Fácil': return 'bg-green-500'
      case 'Medio': return 'bg-yellow-500'
      case 'Difícil': return 'bg-orange-500'
      case 'Maestro': return 'bg-purple-500'
      default: return 'bg-gray-500'
    }
  }

  const isModuleCompleted = (moduleId) => {
    return userProgress.completed_modules.includes(moduleId)
  }

  // Mostrar pantalla de bienvenida
  if (currentView === 'welcome') {
    return (
      <WelcomeScreen 
        videoSrc={welcomeVideo}
        onVideoEnd={() => setCurrentView('login')}
      />
    )
  }

  // Mostrar formulario de login
  if (currentView === 'login') {
    return (
      <LoginForm 
        onLogin={handleLogin}
        onShowRegistration={() => setCurrentView('register')}
      />
    )
  }

  // Mostrar formulario de registro
  if (currentView === 'register') {
    return (
      <RegistrationForm 
        onRegistrationComplete={handleRegistrationComplete}
      />
    )
  }

  // Mostrar módulo de juego
  if (currentView === 'module' && currentModule) {
    return (
      <GameModule 
        module={currentModule}
        onBack={backToMap}
        onComplete={completeModule}
        userProgress={userProgress}
      />
    )
  }

  // Mostrar mapa principal (solo si está autenticado)
  return (
    <div className="adventure-bg min-h-screen">
      {/* Header */}
      <header className="bg-white/90 backdrop-blur-sm shadow-lg">
        <div className="container mx-auto px-4 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-4">
              <h1 className="text-3xl font-bold text-blue-800">🏴‍☠️ Aventura Financiera</h1>
              <Badge variant="secondary" className="text-lg">
                Isla del Tesoro
              </Badge>
              {currentUser && (
                <Badge variant="outline" className="text-sm">
                  ¡Hola, {currentUser.nombre}!
                </Badge>
              )}
            </div>
            <div className="flex items-center space-x-6">
              <div className="flex items-center space-x-2">
                <Coins className="text-yellow-500" />
                <span className="font-bold text-xl">{userProgress.coins}</span>
              </div>
              <div className="flex items-center space-x-2">
                <Star className="text-purple-500" />
                <span className="font-bold">Nivel {userProgress.level}</span>
              </div>
              <div className="flex items-center space-x-2">
                <Trophy className="text-orange-500" />
                <span className="font-bold">{userProgress.completed_modules.length}/8</span>
              </div>
              <Button variant="ghost" onClick={handleLogout}>
                <LogOut className="w-4 h-4 mr-2" />
                Salir
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Sección de Personajes */}
        <section className="mb-12">
          <h2 className="text-4xl font-bold text-center mb-8 text-blue-800">
            🌟 Conoce a tus Compañeros de Aventura
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-6">
            {characters.map((character, index) => (
              <Card 
                key={index} 
                className="character-card cursor-pointer hover:shadow-xl transition-all duration-300"
                onClick={() => openCharacterModal(character)}
              >
                <CardContent className="p-4 text-center">
                  <div className="floating-element">
                    <img 
                      src={character.image} 
                      alt={character.name}
                      className="w-24 h-24 mx-auto mb-4 rounded-full object-cover"
                    />
                  </div>
                  <h3 className="font-bold text-lg mb-2">{character.name}</h3>
                  <Badge variant="outline" className="mb-2">
                    {character.role}
                  </Badge>
                  <Button 
                    size="sm" 
                    variant="ghost"
                    onClick={(e) => {
                      e.stopPropagation()
                      playCharacterAudio(character)
                    }}
                  >
                    <Volume2 className="w-4 h-4" />
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        {/* Mapa de la Isla */}
        <section className="mb-12">
          <h2 className="text-4xl font-bold text-center mb-8 text-blue-800">
            🗺️ Mapa de la Isla del Tesoro Financiero
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {modules.map((module) => (
              <Card 
                key={module.id} 
                className="overflow-hidden hover:shadow-xl transition-all duration-300 transform hover:scale-105"
              >
                <div className="relative">
                  <img 
                    src={module.image} 
                    alt={module.title}
                    className="w-full h-48 object-cover"
                  />
                  <Badge 
                    className={`absolute top-2 right-2 ${getDifficultyColor(module.difficulty)} text-white`}
                  >
                    {module.difficulty}
                  </Badge>
                  {isModuleCompleted(module.id) && (
                    <div className="absolute top-2 left-2 bg-green-500 text-white rounded-full p-1">
                      <Trophy className="w-4 h-4" />
                    </div>
                  )}
                </div>
                <CardHeader>
                  <CardTitle className="text-lg">{module.title}</CardTitle>
                  <CardDescription className="text-sm font-semibold text-blue-600">
                    {module.subtitle}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-sm mb-4">{module.description}</p>
                  <div className="flex justify-between items-center mb-4">
                    <div className="flex items-center space-x-2">
                      <Coins className="w-4 h-4 text-yellow-500" />
                      <span className="font-bold">{module.coins}</span>
                    </div>
                    <Badge variant="secondary">
                      {module.character}
                    </Badge>
                  </div>
                  <Button 
                    className="w-full module-button"
                    onClick={() => startModule(module.id)}
                    disabled={isModuleCompleted(module.id)}
                  >
                    <Play className="w-4 h-4 mr-2" />
                    {isModuleCompleted(module.id) ? 'Completado' : 'Comenzar Aventura'}
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        {/* Progreso General */}
        <section className="mb-12">
          <Card className="treasure-glow">
            <CardHeader>
              <CardTitle className="text-2xl text-center">
                🏆 Tu Progreso en la Aventura
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <div className="flex justify-between mb-2">
                    <span className="font-semibold">Módulos Completados</span>
                    <span>{userProgress.completed_modules.length}/8</span>
                  </div>
                  <Progress 
                    value={(userProgress.completed_modules.length / 8) * 100} 
                    className="h-4"
                  />
                </div>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-6">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-yellow-600">{userProgress.coins}</div>
                    <div className="text-sm text-gray-600">Monedas de Oro</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-purple-600">{userProgress.level}</div>
                    <div className="text-sm text-gray-600">Nivel Actual</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-green-600">{userProgress.badges.length}</div>
                    <div className="text-sm text-gray-600">Insignias</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-blue-600">
                      {Math.round((userProgress.completed_modules.length / 8) * 100)}%
                    </div>
                    <div className="text-sm text-gray-600">Completado</div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </section>
      </div>

      {/* Modal de Personaje */}
      {showCharacterModal && selectedCharacter && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <Card className="max-w-md mx-4">
            <CardHeader>
              <CardTitle className="text-center">{selectedCharacter.name}</CardTitle>
            </CardHeader>
            <CardContent className="text-center">
              <img 
                src={selectedCharacter.image} 
                alt={selectedCharacter.name}
                className="w-32 h-32 mx-auto mb-4 rounded-full object-cover"
              />
              <p className="mb-4">{selectedCharacter.description}</p>
              <div className="flex justify-center space-x-4">
                <Button onClick={() => playCharacterAudio(selectedCharacter)}>
                  <Volume2 className="w-4 h-4 mr-2" />
                  Escuchar
                </Button>
                <Button variant="outline" onClick={() => setShowCharacterModal(false)}>
                  Cerrar
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  )
}

export default App

